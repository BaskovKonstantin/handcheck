"use strict";

const path = require("path");
const http = require("http");
const express = require("express");
const { getDb } = require("./db");
const { seed } = require("./db/seed");
const config = require("./config");
const { attachUser, requireAuth, rejectApiTokenOnRest } = require("./middleware/auth");
const { requireSessionSameOrigin } = require("./middleware/session-same-origin");
const {
  errorHandler,
  INVALID_JSON_BODY_MSG,
  MCP_INVALID_JSON_MSG,
  MCP_PAYLOAD_TOO_LARGE_MSG,
  isMcpRequest,
  sendMcpJsonRpcError,
} = require("./middleware/errors");
const { attachSignaling } = require("./modules/calls/signaling");

const STARTED_AT = new Date().toISOString();

/** Behind Caddy pooled upstreams; must exceed proxy idle time and event-loop stalls from ffmpeg merge. */
const HTTP_KEEP_ALIVE_TIMEOUT_MS = 65_000;
const HTTP_HEADERS_TIMEOUT_MS = 66_000;

function configureHttpServerTimeouts(server, overrides = {}) {
  server.keepAliveTimeout =
    overrides.keepAliveTimeoutMs ?? HTTP_KEEP_ALIVE_TIMEOUT_MS;
  server.headersTimeout = overrides.headersTimeoutMs ?? HTTP_HEADERS_TIMEOUT_MS;
}

function createApp() {
  seed(getDb());

  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", 1);
  app.use(express.json({ limit: "256kb" }));
  app.use(attachUser);

  app.get("/api/health", (_req, res) => {
    res.json({
      ok: true,
      service: "handcheck",
      version: "0.5.0",
      commit: config.GIT_COMMIT,
      startedAt: STARTED_AT,
      now: new Date().toISOString(),
    });
  });

  app.use("/api", requireSessionSameOrigin);
  app.use("/api", rejectApiTokenOnRest);

  app.get("/api/me", requireAuth, (req, res) => {
    res.json({
      id: req.user.id,
      email: req.user.email,
      role: req.user.role,
      emailConfirmed: Boolean(req.user.email_confirmed_at),
    });
  });

  app.use("/api/stats", require("./modules/stats/router"));
  app.use("/api/auth", require("./modules/auth/router"));
  app.use("/api/candidate", require("./modules/employer-tests/candidate-router"));
  app.use("/api/candidate", require("./modules/candidates/router"));
  app.use("/api/employer", require("./modules/employers/router"));
  app.use("/api/employer", require("./modules/needs/router"));
  app.use("/api/employer", require("./modules/matching/router"));
  app.use("/api/employer", require("./modules/deck/router"));
  app.use("/api/employer", require("./modules/invitations/router"));
  app.use("/api/employer", require("./modules/employer-tests/router"));
  // tasks/router must come BEFORE assessment/router: the latter gates every
  // request on requireRole("candidate"), which used to shadow POST /generate.
  app.use("/api/assessment", require("./modules/tasks/router"));
  app.use("/api/assessment", require("./modules/assessment/router"));
  app.use("/api/calls", require("./modules/calls/router"));
  app.use("/api/integrations", require("./modules/integrations/router"));
  app.get("/api/privacy-notice", (_req, res) => {
    const { privacyNoticeShort, privacyNoticeDocument } = require("./lib/privacy-policy");
    res.json({
      short: privacyNoticeShort(),
      ...privacyNoticeDocument(),
    });
  });
  app.use("/mcp", require("./modules/mcp/router"));

  if (process.env.HANDCHECK_TEST_HOOKS === "1") {
    app.post("/api/test-hooks/block-ms", express.json({ limit: "4kb" }), (req, res) => {
      const ms = Math.min(Math.max(0, Number(req.body?.ms) || 0), 10_000);
      const deadline = Date.now() + ms;
      while (Date.now() < deadline) {
        /* intentional event-loop block for keep-alive regression tests */
      }
      res.json({ ok: true });
    });
  }

  app.use("/api", (req, res) => {
    res.status(404).json({ error: "not_found" });
  });

  const publicDir = path.join(__dirname, "public");
  app.get("/auth", (req, res) => {
    if (String(req.query.mode || "") === "register") {
      return res.sendFile(path.join(publicDir, "auth.html"));
    }
    const q = req.url.includes("?") ? req.url.slice(req.url.indexOf("?")) : "";
    return res.redirect(302, `/${q}`);
  });

  const routes = [
    ["/", "index.html"],
    ["/candidate/today", "candidate/today.html"],
    ["/candidate/past", "candidate/past.html"],
    ["/candidate/tasks", "candidate/tasks.html"],
    ["/candidate/invitations", "candidate/invitations.html"],
    ["/candidate/calls", "candidate/calls.html"],
    ["/candidate/profile", "candidate/profile.html"],
    ["/candidate/integrations", "candidate/integrations.html"],
    ["/employer/overview", "employer/overview.html"],
    ["/employer/need", "employer/need.html"],
    ["/employer/tests", "employer/tests.html"],
    ["/employer/deck", "employer/deck.html"],
    ["/employer/candidates", "employer/candidates.html"],
    ["/employer/deferred", "employer/deferred.html"],
    ["/employer/invitations", "employer/invitations.html"],
    ["/employer/calls", "employer/calls.html"],
    ["/employer/profile", "employer/profile.html"],
    ["/employer/integrations", "employer/integrations.html"],
    ["/privacy", "privacy.html"],
  ];
  for (const [url, file] of routes) {
    app.get(url, (_req, res) => res.sendFile(path.join(publicDir, file)));
  }
  app.get("/employer/list", (req, res) => {
    const q = req.url.includes("?") ? req.url.slice(req.url.indexOf("?")) : "";
    res.redirect(302, `/employer/candidates${q}`);
  });
  app.get("/call/:invitationId", (_req, res) => {
    res.sendFile(path.join(publicDir, "call.html"));
  });

  app.use(express.static(publicDir));

  app.get("*", (_req, res) => {
    res.status(404).sendFile(path.join(publicDir, "404.html"));
  });

  app.use((err, req, res, next) => {
    if (err && err.type === "entity.parse.failed") {
      if (isMcpRequest(req)) {
        return sendMcpJsonRpcError(res, 400, -32700, MCP_INVALID_JSON_MSG);
      }
      return res.status(400).json({
        error: "invalid_body",
        details: { message: INVALID_JSON_BODY_MSG },
      });
    }
    next(err);
  });

  app.use((err, req, res, next) => {
    if (err && err.type === "entity.too.large") {
      if (isMcpRequest(req)) {
        return sendMcpJsonRpcError(res, 413, -32000, MCP_PAYLOAD_TOO_LARGE_MSG);
      }
      return res.status(413).json({
        error: "payload_too_large",
        details: {
          message: MCP_PAYLOAD_TOO_LARGE_MSG,
        },
      });
    }
    next(err);
  });

  app.use(errorHandler);
  return app;
}

function start(options = {}) {
  const app = createApp();
  const server = http.createServer(app);
  configureHttpServerTimeouts(server, options);
  attachSignaling(server);
  server.listen(options.port ?? config.PORT, "0.0.0.0", () => {
    // eslint-disable-next-line no-console
    console.log(`handcheck listening on :${config.PORT}`);
  });
  return server;
}

if (require.main === module) {
  start();
}

module.exports = {
  createApp,
  start,
  configureHttpServerTimeouts,
  HTTP_KEEP_ALIVE_TIMEOUT_MS,
  HTTP_HEADERS_TIMEOUT_MS,
};
