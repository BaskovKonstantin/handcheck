/* global HandCheck */
"use strict";

(function (global) {
  const WS_SIGNAL = {
    OFFER: "offer",
    ANSWER: "answer",
    ICE: "ice",
    ENDED: "ended",
    HELLO: "hello",
    PEER_LEFT: "peer_left",
  };

  /** Target total bitrate so ~60 min fits in 80 MB upload limit (with headroom). */
  const RECORDING_LIMIT_BYTES = 80 * 1024 * 1024;
  const RECORDING_TARGET_SECONDS = 60 * 60;
  const RECORDER_VIDEO_BPS = 100_000;
  const RECORDER_AUDIO_BPS = 15_000;
  const RECORDER_TOTAL_BPS = RECORDER_VIDEO_BPS + RECORDER_AUDIO_BPS;
  const CHUNK_UPLOAD_MS = 3_000;
  /** Chromium keepalive fetch body limit (~64 KB). */
  const KEEPALIVE_BODY_LIMIT = 60 * 1024;
  const FINALIZE_RETRY_STATUSES = new Set([502, 503, 504]);
  const FINALIZE_MAX_ATTEMPTS = 5;
  const FINALIZE_RETRY_BASE_MS = 600;
  const FINALIZE_RETRY_MAX_MS = 8_000;

  function shouldAttachFinalizeTail(attemptIndex, tailSize, tailSentOnPriorAttempt) {
    if (!tailSize) return false;
    if (attemptIndex === 0) return true;
    return !tailSentOnPriorAttempt;
  }

  function finalizeRetryDelayMs(attemptIndex) {
    const exp = Math.min(
      FINALIZE_RETRY_BASE_MS * 2 ** Math.max(0, attemptIndex - 1),
      FINALIZE_RETRY_MAX_MS
    );
    return exp;
  }

  function finalizeNeedsTailAgain(status, body, tailSentOnPriorAttempt) {
    if (!tailSentOnPriorAttempt) return false;
    if (status !== 400) return false;
    const code = body?.error;
    return code === "file_required" || code === "invalid_recording";
  }

  function sleepMs(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function wsUrl(callId) {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    return `${proto}//${location.host}/ws/calls/${callId}`;
  }

  async function parseSignal(raw) {
    let text = raw;
    if (typeof raw !== "string") {
      if (raw instanceof Blob) {
        text = await raw.text();
      } else if (raw instanceof ArrayBuffer) {
        text = new TextDecoder().decode(raw);
      } else if (raw && typeof raw.byteLength === "number") {
        text = new TextDecoder().decode(new Uint8Array(raw));
      } else {
        text = String(raw);
      }
    }
    try {
      const msg = JSON.parse(text);
      if (msg && typeof msg.t === "string") return msg;
    } catch {
      /* ignore */
    }
    return null;
  }

  function pickRecorderMime() {
    const types = [
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm",
    ];
    for (const t of types) {
      if (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(t)) return t;
    }
    return "";
  }

  function recorderFitsPlanLimit() {
    const bytesPerSecond = RECORDER_TOTAL_BPS / 8;
    const projected = bytesPerSecond * RECORDING_TARGET_SECONDS;
    return projected <= RECORDING_LIMIT_BYTES * 0.85;
  }

  /**
   * @param {object} opts
   * @param {string} opts.callId
   * @param {string} opts.role - employer | candidate
   * @param {() => void} [opts.onPeerEnded]
   * @param {(state: object) => void} [opts.onState]
   * @param {(message: string) => void} [opts.onUploadError]
   * @param {() => void} [opts.onUploadRecovered]
   * @param {(message: string) => void} [opts.onTranscriptError]
   */
  function createCallSession(opts) {
    const { callId, role, onPeerEnded, onState, onUploadError, onUploadRecovered, onTranscriptError } =
      opts;
    let ws = null;
    let pc = null;
    let localStream = null;
    let remoteStream = null;
    let recorder = null;
    let uploadedChunkCount = 0;
    let keepaliveBytesInFlight = 0;
    let chunkUploadFailed = false;
    let chunkUploadTimer = null;
    let chunkQueue = null;
    let peerLeft = false;
    let peerWasConnected = false;
    let disconnectSince = null;
    let speech = null;
    let speechNoteShown = false;
    let speechStopped = false;
    let speechRestartAttempts = 0;
    let pollTimer = null;
    let ended = false;
    let liveFeaturesStarted = false;
    let liveStartedAt = null;
    let recordingUploadDegraded = false;

    function peerIsConnected() {
      return pc?.connectionState === "connected";
    }

    function emit(patch = {}) {
      if (typeof patch.recordingUploadDegraded === "boolean") {
        recordingUploadDegraded = patch.recordingUploadDegraded;
      }
      if (typeof onState === "function") {
        onState({
          peerConnected: peerIsConnected(),
          connectionState: pc?.connectionState || "new",
          recording: Boolean(recorder && recorder.state === "recording"),
          recordingUploadDegraded,
          speechAvailable: Boolean(speech),
          speechNote: speechNoteShown ? "Расшифровка недоступна в этом браузере" : "",
          ...patch,
        });
      }
    }

    function sendSignal(msg) {
      if (ws && ws.readyState === 1) ws.send(JSON.stringify(msg));
    }

    async function resetPeerIfNeeded() {
      if (!pc) return;
      if (["disconnected", "failed", "closed"].includes(pc.connectionState)) {
        try {
          pc.close();
        } catch {
          /* ignore */
        }
        pc = null;
        remoteStream = null;
      }
    }

    async function ensurePeerConnection() {
      if (pc) return pc;
      pc = new RTCPeerConnection({
        iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
      });
      pc.onicecandidate = (ev) => {
        if (ev.candidate) sendSignal({ t: WS_SIGNAL.ICE, candidate: ev.candidate });
      };
      pc.ontrack = (ev) => {
        if (!remoteStream) remoteStream = new MediaStream();
        ev.streams[0]?.getTracks().forEach((tr) => {
          if (!remoteStream.getTracks().some((x) => x.id === tr.id)) remoteStream.addTrack(tr);
        });
        emit({});
      };
      pc.onconnectionstatechange = () => {
        const state = pc.connectionState;
        if (state === "connected") {
          peerWasConnected = true;
          disconnectSince = null;
        } else if (
          peerWasConnected &&
          !peerLeft &&
          !ended &&
          ["disconnected", "failed"].includes(state)
        ) {
          if (!disconnectSince) disconnectSince = Date.now();
          const stuckMs = Date.now() - disconnectSince;
          if (stuckMs > 25_000) {
            peerLeft = true;
            emit({ peerLeft: true, peerConnected: false, connectionState: state });
          }
        }
        emit({ connectionState: state, peerLeft });
        if (
          role === "employer" &&
          !ended &&
          !peerLeft &&
          ["disconnected", "failed"].includes(state)
        ) {
          setTimeout(() => sendOffer().catch(() => {}), 400);
        }
      };
      if (localStream) {
        localStream.getTracks().forEach((tr) => pc.addTrack(tr, localStream));
      }
      return pc;
    }

    async function handleSignal(msg) {
      if (!msg || ended) return;
      if (msg.t === WS_SIGNAL.HELLO) {
        peerLeft = false;
        disconnectSince = null;
        if (role === "employer") {
          await resetPeerIfNeeded();
          await sendOffer();
        } else {
          await ensurePeerConnection();
        }
        return;
      }
      const conn = await ensurePeerConnection();
      if (msg.t === WS_SIGNAL.OFFER && role === "candidate") {
        if (conn.signalingState === "stable" && conn.remoteDescription) {
          if (conn.connectionState === "connected") return;
          try {
            conn.close();
          } catch {
            /* ignore */
          }
          pc = null;
          remoteStream = null;
          const fresh = await ensurePeerConnection();
          if (fresh.signalingState === "have-local-offer") return;
          try {
            await fresh.setRemoteDescription(msg.sdp);
            const answer = await fresh.createAnswer();
            await fresh.setLocalDescription(answer);
            sendSignal({ t: WS_SIGNAL.ANSWER, sdp: fresh.localDescription });
          } catch {
            /* glare or stale offer */
          }
          return;
        }
        if (conn.signalingState === "have-local-offer") return;
        try {
          await conn.setRemoteDescription(msg.sdp);
          const answer = await conn.createAnswer();
          await conn.setLocalDescription(answer);
          sendSignal({ t: WS_SIGNAL.ANSWER, sdp: conn.localDescription });
        } catch {
          /* glare or stale offer */
        }
      } else if (msg.t === WS_SIGNAL.ANSWER && role === "employer") {
        if (conn.signalingState !== "have-local-offer") return;
        try {
          await conn.setRemoteDescription(msg.sdp);
        } catch {
          /* duplicate or stale answer */
        }
      } else if (msg.t === WS_SIGNAL.ICE && msg.candidate) {
        try {
          await conn.addIceCandidate(msg.candidate);
        } catch {
          /* ignore stale ice */
        }
      } else if (msg.t === WS_SIGNAL.PEER_LEFT) {
        if (ended || peerLeft) return;
        peerLeft = true;
        emit({ peerLeft: true, peerConnected: false });
      } else if (msg.t === WS_SIGNAL.ENDED) {
        if (ended) return;
        peerLeft = true;
        emit({ peerLeft: true, peerConnected: false });
        ended = true;
        if (typeof onPeerEnded === "function") onPeerEnded();
      }
    }

    let offerRetryTimer = null;

    async function sendOffer() {
      if (role !== "employer" || ended) return;
      await resetPeerIfNeeded();
      const conn = await ensurePeerConnection();
      if (conn.connectionState === "connected") return;
      const offer = await conn.createOffer({ iceRestart: conn.connectionState === "failed" });
      await conn.setLocalDescription(offer);
      sendSignal({ t: WS_SIGNAL.OFFER, sdp: conn.localDescription });
    }

    async function connectSignaling() {
      if (ws) return;
      ws = new WebSocket(wsUrl(callId));
      ws.onmessage = (ev) => {
        parseSignal(ev.data).then((msg) => {
          if (msg) handleSignal(msg);
        });
      };
      ws.onopen = async () => {
        emit({ wsOpen: true });
        sendSignal({ t: WS_SIGNAL.HELLO, role });
        if (role === "employer") {
          await sendOffer();
          clearInterval(offerRetryTimer);
          offerRetryTimer = setInterval(() => {
            if (peerIsConnected()) {
              clearInterval(offerRetryTimer);
              return;
            }
            sendOffer().catch(() => {});
          }, 1500);
        } else {
          await ensurePeerConnection();
        }
      };
    }

    function restartSpeech(delayMs) {
      if (ended || speechStopped || !speech) return;
      if (speechRestartAttempts > 8) {
        speechNoteShown = true;
        speech = null;
        emit({});
        return;
      }
      speechRestartAttempts += 1;
      setTimeout(() => {
        if (ended || speechStopped || !speech) return;
        try {
          speech.start();
        } catch {
          speechNoteShown = true;
          speech = null;
          emit({});
        }
      }, delayMs);
    }

    function startSpeechRecognition() {
      const Ctor = global.SpeechRecognition || global.webkitSpeechRecognition;
      if (!Ctor) {
        speechNoteShown = true;
        emit({});
        return;
      }
      speech = new Ctor();
      speech.lang = "ru-RU";
      speech.continuous = true;
      speech.interimResults = false;
      speech.onresult = (ev) => {
        const at =
          liveStartedAt != null ? Math.max(0, Math.round((Date.now() - liveStartedAt) / 1000)) : 0;
        for (let i = ev.resultIndex; i < ev.results.length; i += 1) {
          const res = ev.results[i];
          if (!res.isFinal) continue;
          const text = String(res[0]?.transcript || "").trim();
          if (!text) continue;
          HandCheck.api(`/api/calls/${callId}/transcript-chunk`, {
            method: "POST",
            body: JSON.stringify({ text, at }),
          }).catch(() => {
            if (typeof onTranscriptError === "function") {
              onTranscriptError("Не удалось сохранить реплику расшифровки");
            }
          });
        }
      };
      speech.onerror = (ev) => {
        if (ended || speechStopped) return;
        const code = ev?.error || "";
        if (code === "network" || code === "aborted" || code === "no-speech") {
          restartSpeech(300 + speechRestartAttempts * 200);
          return;
        }
        speechNoteShown = true;
        emit({});
      };
      speech.onend = () => {
        if (!ended && !speechStopped) restartSpeech(250 + speechRestartAttempts * 350);
      };
      try {
        speech.start();
      } catch {
        speechNoteShown = true;
        speech = null;
      }
      emit({});
    }

    function startRecorder(stream) {
      const mime = pickRecorderMime();
      if (!mime || typeof MediaRecorder === "undefined") {
        emit({ recording: false, recordingUnavailable: true });
        return;
      }
      const { createRecordingChunkQueue } = global.HandCheckRecordingChunkQueue || {};
      chunkQueue = createRecordingChunkQueue
        ? createRecordingChunkQueue({
            uploadBlob: async (parts) => {
              const blob = new Blob(parts, { type: mime });
              await uploadRecordingChunk(blob);
            },
            onUploadFailure: () => {
              if (!chunkUploadFailed) {
                chunkUploadFailed = true;
                emit({ recordingUploadDegraded: true });
                if (typeof onUploadError === "function") {
                  onUploadError(
                    "Сбой загрузки фрагмента записи — повторяем автоматически"
                  );
                }
              }
            },
            onUploadSuccess: () => {
              if (chunkUploadFailed) {
                chunkUploadFailed = false;
                emit({ recordingUploadDegraded: false });
                if (typeof onUploadRecovered === "function") {
                  onUploadRecovered();
                }
              }
            },
          })
        : null;
      recorder = new MediaRecorder(stream, {
        mimeType: mime,
        videoBitsPerSecond: RECORDER_VIDEO_BPS,
        audioBitsPerSecond: RECORDER_AUDIO_BPS,
      });
      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          if (chunkQueue) chunkQueue.push(ev.data);
        }
      };
      recorder.start(1000);
      emit({ recording: true });
    }

    async function postMultipart(url, form, blobSize, options = {}) {
      const wantKeepalive = Boolean(options.keepalive);
      const useKeepalive =
        wantKeepalive && blobSize > 0 && blobSize <= KEEPALIVE_BODY_LIMIT;
      const res = await fetch(url, {
        method: "POST",
        credentials: "include",
        body: form,
        keepalive: useKeepalive,
      });
      return res;
    }

    async function uploadRecordingChunk(blob) {
      if (!blob?.size) return;
      const form = new FormData();
      form.append("file", blob, `chunk-${uploadedChunkCount}.webm`);
      const res = await postMultipart(
        `/api/calls/${callId}/recording-chunk`,
        form,
        blob.size,
        { keepalive: false }
      );
      if (!res.ok) throw new Error("chunk_upload_failed");
      uploadedChunkCount += 1;
      return true;
    }

    async function flushRecordingChunks() {
      if (!chunkQueue) return;
      await chunkQueue.flush();
    }

    function liveDurationMs() {
      const key = `handcheck_call_live_${callId}`;
      let since = liveStartedAt;
      try {
        const stored = global.sessionStorage?.getItem(key);
        if (stored) since = Number(stored) || since;
      } catch {
        /* ignore */
      }
      return since != null ? Math.max(0, Date.now() - since) : 0;
    }

    function uploadKeepaliveBatch(parts) {
      const mime = pickRecorderMime() || "video/webm";
      const blob = new Blob(parts, { type: mime });
      if (!blob.size || blob.size > KEEPALIVE_BODY_LIMIT) {
        chunkQueue?.requeueParts?.(parts);
        return;
      }
      if (keepaliveBytesInFlight + blob.size > KEEPALIVE_BODY_LIMIT) {
        chunkQueue?.requeueParts?.(parts);
        return;
      }
      keepaliveBytesInFlight += blob.size;
      const form = new FormData();
      form.append("file", blob, `chunk-emergency-${uploadedChunkCount}.webm`);
      void postMultipart(`/api/calls/${callId}/recording-chunk`, form, blob.size, {
        keepalive: true,
      })
        .then((res) => {
          keepaliveBytesInFlight -= blob.size;
          if (res?.ok) uploadedChunkCount += 1;
          else chunkQueue?.requeueParts?.(parts);
        })
        .catch(() => {
          keepaliveBytesInFlight -= blob.size;
          chunkQueue?.requeueParts?.(parts);
        });
    }

    function emergencyUploadPendingRecording() {
      if (!chunkQueue?.emergencyFlushKeepalive) return;
      chunkQueue.emergencyFlushKeepalive((parts) => uploadKeepaliveBatch(parts));
    }

    function flushRecordingOnPageExit() {
      try {
        if (recorder && recorder.state !== "inactive" && typeof recorder.requestData === "function") {
          recorder.requestData();
        }
      } catch {
        /* ignore */
      }
      emergencyUploadPendingRecording();
    }

    function startChunkUploadLoop() {
      clearInterval(chunkUploadTimer);
      chunkUploadTimer = setInterval(() => {
        flushRecordingChunks().catch(() => {
          chunkUploadFailed = true;
          emit({ recordingUploadDegraded: true });
          if (typeof onUploadError === "function") {
            onUploadError("Сбой загрузки фрагмента записи — повторяем автоматически");
          }
        });
      }, CHUNK_UPLOAD_MS);
      const onPageHide = () => {
        flushRecordingOnPageExit();
      };
      const onVisibility = () => {
        if (global.document?.visibilityState === "hidden") flushRecordingOnPageExit();
      };
      global.addEventListener("pagehide", onPageHide);
      global.addEventListener("beforeunload", onPageHide);
      global.document?.addEventListener("visibilitychange", onVisibility);
    }

    let uploadRecordingLock = Promise.resolve();

    async function uploadRecording() {
      const run = async () => {
        if (recorder && recorder.state !== "inactive") {
          await new Promise((resolve) => {
            recorder.onstop = () => resolve();
            recorder.stop();
          });
        }
        try {
          await flushRecordingChunks();
          if (chunkQueue) await chunkQueue.waitForIdle();
        } catch {
          chunkUploadFailed = true;
        }
        const mime = pickRecorderMime() || "video/webm";
        const tail = chunkQueue ? chunkQueue.drainRemainingBlobs(mime) : null;
        const durationMs = liveDurationMs();
        const tailSize = tail?.size || 0;
        let tailSentOnPriorAttempt = false;
        let forceTailAgain = false;
        let lastErr = null;
        for (let attempt = 0; attempt < FINALIZE_MAX_ATTEMPTS; attempt += 1) {
          if (attempt > 0) {
            await sleepMs(finalizeRetryDelayMs(attempt));
          }
          const attachTail =
            tailSize > 0 &&
            (forceTailAgain || shouldAttachFinalizeTail(attempt, tailSize, tailSentOnPriorAttempt));
          const form = new FormData();
          if (attachTail) {
            form.append("file", tail, "recording.webm");
          }
          form.append("durationMs", String(durationMs));
          const bodySize = attachTail ? tailSize : 0;
          let res;
          try {
            res = await postMultipart(`/api/calls/${callId}/recording`, form, bodySize, {
              keepalive: false,
            });
          } catch (err) {
            lastErr = err;
            if (attempt < FINALIZE_MAX_ATTEMPTS - 1) continue;
            break;
          }
          if (res.ok) return;
          const err = await res.json().catch(() => ({}));
          lastErr = err;
          if (attachTail) tailSentOnPriorAttempt = true;
          if (finalizeNeedsTailAgain(res.status, err, tailSentOnPriorAttempt)) {
            forceTailAgain = true;
            if (attempt < FINALIZE_MAX_ATTEMPTS - 1) continue;
          }
          if (FINALIZE_RETRY_STATUSES.has(res.status) && attempt < FINALIZE_MAX_ATTEMPTS - 1) {
            continue;
          }
          const code = err?.error || `recording_upload_${res.status}`;
          const message =
            res.status === 413
              ? "Запись слишком большая (максимум 80 МБ). Сократите звонок или обратитесь в поддержку."
              : HandCheck.formatApiError?.({ data: err, message: code }) || "Не удалось сохранить запись";
          if (typeof onUploadError === "function") onUploadError(message);
          throw new Error(code);
        }
        if (typeof onUploadError === "function") {
          onUploadError("Не удалось сохранить запись");
        }
        throw lastErr || new Error("recording_upload_failed");
      };
      uploadRecordingLock = uploadRecordingLock.then(run, run);
      return uploadRecordingLock;
    }

    function startStatusPoll(onEndedRemote) {
      clearInterval(pollTimer);
      pollTimer = setInterval(async () => {
        if (ended) return;
        try {
          const info = await HandCheck.api(`/api/calls/for-invitation/${opts.invitationId}`);
          if (info.status === "ended") {
            ended = true;
            if (typeof onEndedRemote === "function") onEndedRemote(info);
          }
        } catch {
          /* ignore */
        }
      }, 2500);
    }

    return {
      getLocalStream: () => localStream,
      getRemoteStream: () => remoteStream,
      getConnectionState: () => pc?.connectionState || "new",
      async attachLocalMedia(stream) {
        localStream = stream;
        if (pc) {
          stream.getTracks().forEach((tr) => pc.addTrack(tr, stream));
        }
      },
      async connectSignaling() {
        await connectSignaling();
      },
      async startLiveFeatures() {
        if (liveFeaturesStarted) return;
        liveFeaturesStarted = true;
        liveStartedAt = Date.now();
        try {
          const key = `handcheck_call_live_${callId}`;
          if (!global.sessionStorage?.getItem(key)) {
            global.sessionStorage?.setItem(key, String(liveStartedAt));
          }
        } catch {
          /* ignore */
        }
        startRecorder(localStream);
        startChunkUploadLoop();
        startSpeechRecognition();
        startStatusPoll((info) => {
          if (typeof onPeerEnded === "function") onPeerEnded(info);
        });
        emit({});
      },
      async endLocalSide(options = {}) {
        const { skipUpload = false, waitForUpload = false } = options;
        ended = true;
        speechStopped = true;
        sendSignal({ t: WS_SIGNAL.ENDED });
        clearInterval(pollTimer);
        clearInterval(offerRetryTimer);
        clearInterval(chunkUploadTimer);
        if (speech) {
          try {
            speech.stop();
          } catch {
            /* ignore */
          }
          speech = null;
        }
        const uploadPromise =
          !skipUpload && liveFeaturesStarted
            ? uploadRecording().catch(() => {})
            : Promise.resolve();
        if (waitForUpload) await uploadPromise;
        if (ws) {
          ws.close();
          ws = null;
        }
        if (pc) {
          pc.close();
          pc = null;
        }
        if (localStream) {
          localStream.getTracks().forEach((t) => t.stop());
          localStream = null;
        }
        emit({ recording: false });
        return uploadPromise;
      },
      notifyPeerEnded() {
        sendSignal({ t: WS_SIGNAL.ENDED });
      },
    };
  }

  global.HandCheckCallRoom = {
    createCallSession,
    pickRecorderMime,
    parseSignal,
    recorderFitsPlanLimit,
    RECORDER_TOTAL_BPS,
    RECORDING_LIMIT_BYTES,
    RECORDING_TARGET_SECONDS,
    KEEPALIVE_BODY_LIMIT,
    shouldAttachFinalizeTail,
    finalizeRetryDelayMs,
    finalizeNeedsTailAgain,
    FINALIZE_MAX_ATTEMPTS,
    _WS_SIGNAL: WS_SIGNAL,
  };
})(window);
